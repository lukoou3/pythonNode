(function(){
	$("#iw").val("admin");
	$("#e").val("+UMC!s0-");
	$("input:submit").click();
})();