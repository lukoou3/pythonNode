(function(){
	setTimeout(function(){
		sendMessageBack('localStorageGet', "umc_auto_login_enable", function(response){
			if(response != "true"){
				return;
			}
			
			injectCustomJs('js/inject.js');
		});
		
	},200)
	document.addEventListener('DOMContentLoaded', function(){
		//console.log('我被执行了！');
	});
	// 向页面注入JS
	function injectCustomJs(jsPath)
	{
		jsPath = jsPath || 'js/inject.js';
		var temp = document.createElement('script');
		temp.setAttribute('type', 'text/javascript');
		// 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
		temp.src = chrome.extension.getURL(jsPath);
		temp.onload = function()
		{
			// 放在页面不好看，执行完后移除掉
			//this.parentNode.removeChild(this);
		};
		document.head.appendChild(temp);
	}
})();

/**
 * 向background发送消息
 * @params strAction string 执行方法
 * @params dicData dict 数据字典
 * @params callback function 回调函数
 */
function sendMessageBack(strAction, dicData, callback){
    chrome.extension.sendMessage({'action': strAction, 'data': dicData}, callback);
}