$(function(){
	var umc_auto_login_enable = localStorage.umc_auto_login_enable == "true";
	$("#umc_auto_login_enable").prop("checked",umc_auto_login_enable);
	var bug_people_filter_enable = localStorage.bug_people_filter_enable == "true";
	$("#bug_people_filter_enable").prop("checked",bug_people_filter_enable);
	
	$("#umc_auto_login_enable").on("change",function(){
		sendMessageBack('localStorageSave', [["umc_auto_login_enable",this.checked]], function(response){});
	});


	$("#bug_people_filter_enable").on("change",function(){
		sendMessageBack('localStorageSave', [["bug_people_filter_enable",this.checked]], function(response){});
	});
});

/**
 * 向background发送消息
 * @params strAction string 执行方法
 * @params dicData dict 数据字典
 * @params callback function 回调函数
 */
function sendMessageBack(strAction, dicData, callback){
    chrome.extension.sendMessage({'action': strAction, 'data': dicData}, callback);
}